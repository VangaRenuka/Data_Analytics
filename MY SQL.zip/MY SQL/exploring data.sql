-- Exploratory DATa Analaysis

SELECT *
FROM layoffs_staging2 ;

SELECT MAx(total_laid_off), max(percentage_laid_off)
FROM layoffs_staging2 ;

SELECT *
FROM layoffs_staging2 
WHERE percentage_laid_off=1
#ORDER by total_laid_off DESC;
ORDER by  funds_raised_millions DESC;

SELECT company , SUM(total_laid_off)
FROM layoffs_staging2
group by company
ORDER by 2 DESC;

SELECT industry , SUM(total_laid_off)
FROM layoffs_staging2
group by industry
ORDER by 2 DESC;

SELECT country , SUM(total_laid_off)
FROM layoffs_staging2
group by country
ORDER by 2 DESC;

SELECT MIN(`date`),MAX(`date`)
FROM layoffs_staging2;


SELECT *
FROM layoffs_staging2 ;

SELECT `date` , SUM(total_laid_off)
FROM layoffs_staging2
group by `date`
ORDER by 1 DESC;

SELECT YEAR(`date`) , SUM(total_laid_off)
FROM layoffs_staging2
group by YEAR(`date`)
ORDER by 1 DESC;

SELECT stage , SUM(total_laid_off)
FROM layoffs_staging2
group by stage
ORDER by 1 DESC;

SELECT company , AVG(percentage_laid_off)
FROM layoffs_staging2
group by company
ORDER by  2 DESC;



SELECT SUBSTRING( `date`,1,7) AS` MONTH` , SUM(total_laid_off)
FROM layoffs_staging2
WHERE SUBSTRING( `date`,1,7) IS NOT NULL
GROUP BY `Month`
ORDER by 1 ASC
 ;
 
 WITH Rolling_Total As
 (
 SELECT SUBSTRING( `date`,1,7) AS` MONTH` , SUM(total_laid_off) AS total_off
FROM layoffs_staging2
WHERE SUBSTRING( `date`,1,7) IS NOT NULL
GROUP BY `Month`
ORDER by 1 ASC)
 SELECT `Month`,total_off ,  SUM(total_off) OVER(ORDER BY `MONTH`) AS rolling_total
 FROM Rolling_Total;
 
 
SELECT company ,YEAR( `date`) ,SUM(total_laid_off)
FROM layoffs_staging2
group by company, YEAR(`date`)
ORDER BY 3 DESC
;

WITH Company_Year(company,years,total_laid_off) AS(
SELECT company ,YEAR( `date`) ,SUM(total_laid_off)
FROM layoffs_staging2
group by company, YEAR(`date`)
),Company_Year_Rank AS (
SELECT *, dense_rank() over(partition by years order by total_laid_off desc) as ranking
FROM Company_Year
Where years is not null )
SELECT *
FROM Company_Year_Rank
WHERE Ranking <= 5
;
