-- Window functions

SELECT dem.first_name,dem.last_name, gender ,AVG(salary) as avg_Sal
FROM  employee_demographics dem
Join employee_salary sal
 ON dem.employee_id = sal.employee_id
 GROUP BY dem.first_name, dem.last_name,gender;
 
 -- implementing window function
 
 SELECT  dem.first_name, dem.last_name , AVG(salary) OVER(PARTITION BY gender)
FROM  employee_demographics dem
Join employee_salary sal
 ON dem.employee_id = sal.employee_id
 ;
 
 
 
 SELECT  dem.first_name, dem.last_name , gender , salary,
SUM(salary) OVER(PARTITION BY gender ORDER BY dem.employee_id) as rolling_Total
FROM  employee_demographics dem
Join employee_salary sal
 ON dem.employee_id = sal.employee_id
 ;
 
 
  SELECT  dem.employee_id, dem.first_name, dem.last_name , gender , salary,
ROW_NUMBER() OVER( partition by gender ORDER BY salary DESC) as row_num,
RANK()  OVER(partition by gender ORDER BY salary DESC) rank_num ,
DENSE_RANK()  OVER(partition by gender ORDER BY salary DESC) dense_num
FROM  employee_demographics dem
Join employee_salary sal
 ON dem.employee_id = sal.employee_id
 ;
 