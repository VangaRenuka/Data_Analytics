-- UNIONS

SELECt  first_name , last_name
FROM employee_demographics
#UNION DISTINCT
UNION ALL
SELECT first_name , last_name
FROM employee_salary;


SELECt  first_name , last_name , 'OLD MAN' AS label
FROM employee_demographics
WHERE age > 40 AND gender='Male'
UNION
SELECt  first_name , last_name , 'OLD WOMEN' AS label
FROM employee_demographics
WHERE age > 40 AND gender='Female'
UNION
SELECt  first_name , last_name , 'Highly_paid' AS label
FROM employee_salary
WHERE salary > 70000
ORDER by first_name, last_name
;
 