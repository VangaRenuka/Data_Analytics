-- String Functions

SELECT Length('Renuka') ;

SELECT first_name, UPPER(first_name)
FROM employee_demographics
ORDER BY 2;

SELECT UPPER('sky');
SELECT Lower('SKY');


SELECT  RTRIM('        SKY      '); #LTRIM #TRIM

SELECT first_name,
RIGHT(first_name,4),
LEFT(firsT_name, 3),

--- SUBSTRING 
SUBSTRING(first_name,3,2), # thir position and  2 characters
birth_Date,
SUBSTRING(birth_date, 9,2) as birth_date
FROM employee_demographics;

-- REPLACE

SELECT  first_name , REPLACE(first_name , 'a' , 'z')
FROM  employee_demographics;

-- LOCATE

SELECT LOCATE('x','Alexander');

SELECT  first_name , LOCATE( 'An', first_name)
FROM  employee_demographics;

SELECT first_name, last_name,
CONCAT(first_name, ' ', last_name) as full_name
FROM employee_demographics;
																																																																																																																																																																						