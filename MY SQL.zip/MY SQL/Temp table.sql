-- Temporary Tables 

CREATE TEMPORARY TABLE temp_table
(
first_name varchar(50),
last_name varchar(50),
favourite_movie varchar (100)
);
SELECT *
FROM temp_table;

INSERT INTO temp_table 
VALUES('Alex','Freberg','Lord of the Rings:The two Towers') ;

SELECT *
FROM temp_table;

SELECT *
From employee_salary ;

Create TEMPORARY TAble salary_over_50k
SELECT*
From employee_salary
WHERE salary >= 50000 ;

SELECT *
From salary_over_50k ;

